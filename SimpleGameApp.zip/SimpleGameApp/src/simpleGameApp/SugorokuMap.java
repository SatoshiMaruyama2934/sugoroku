package simpleGameApp;

import java.util.Random;

public class SugorokuMap {
	private String map;			//マップ情報（文字列）
	private final int MAP_SIZE;//マップの大きさ（ゴールまでのマス数）

//	public boolean isBlank(Player player) {
//		到達したマスの判定（マスの種類ごと）
//	}

	public String getMap() {	//getter
		return map;		
	}

	private final void generateMap() {			//マップの生成
		final String[] POINT = {"+","-","*"};	//生成されるマスの種類
		Random rd = new Random();				//乱数
		map="S";								//スタート地点
		for(int i=1;i<MAP_SIZE;i++) {			//スタート-ゴール間のマス
			map += POINT[rd.nextInt(POINT.length)];	//ランダムにマスを生成
		}
		map+="G";	//ゴール(スタートからMAP_SIZEマス先)
	}
	
	SugorokuMap(int mapSize){		
		this.MAP_SIZE=mapSize;	
		generateMap();			//マップの生成
	}

}
