package simpleGameApp;
/*
 * ゲームの進行機能
 * turnStart ターン開始
 * turnChange ターン進行
 * 
 * input 行動の選択
 * diceRoll さいころを振る
 * checkMap マップの確認
 * goalRank 順位の判定
 * showResult 結果発表
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class SugorokuFunction {
	private int turn = 1;
	private int rank = 1;

	public void turnStart(Player ply) {		//ターン開始時の表示
		System.out.println("");
		System.out.println("/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/");
		System.out.println("");
		System.out.printf("%dターン目：%sさんの番です\n", turn, ply.getName());
		load();
	}

	public String input() {	//入力
		System.out.printf("行動を選択してください。\n「1」でさいころを振る\n「2」でマップを確認 :");
		return new Scanner(System.in).nextLine();
	}

	public int diceRoll() {		//さいころを振る操作
		load();
		int dice = new Random().nextInt(6) + 1;
		System.out.println("さいころを振ります...");
		load(3);
		System.out.printf("==>[%d]が出ました\n", dice);
		return dice;
	}

	public void checkMap(SugorokuMap map, Player turnPlayer, boolean isCommanded) {
		if (isCommanded) {
			System.out.println("マップを表示します（左端が現在地です）");
		}
		load();
		System.out.println(map.getMap().substring(turnPlayer.getLocation()));
		System.out.println("^"); // 現在地マーカー
		load();
		System.out.printf("現在[%d]マス目（[%c]マス）にいます\n", turnPlayer.getLocation(), turnPlayer.getSquare());
		load(3);
	}

	public void turnChange() {	//表示用のターンをセット
		turn++;
	}

	public void goalRank(Player ply) {//ゴール順位のセット
		ply.setRank(rank);
		rank++;
	}

	public void showResult(List<Player> ply) {//結果発表
		System.out.println("/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/*/");
		load();
		System.out.println("～～～～結果発表～～～～");
		load(4);

		List<Player> ranked = sortRank(ply); // 順位ごとにソート
		for (Player ranks : ranked) {
			System.out.printf("%d位:%s\n", ranks.getRank(), ranks.getName());// 上位から出力
			load(2);
		}
		load();
		System.out.println("～game over～");
	}

	private List<Player> sortRank(List<Player> ply) { // 順位で昇順ソート
		List<Player> ranked = new ArrayList<>();
		int rankCount = 1; // 順位情報を走査する変数
		while (rankCount <= ply.size()) { // 最下位の判定が終了するまで
			for (int i = 0; i < ply.size(); i++) { // 各プレイヤーに対して調査
				if (ply.get(i).getRank() == rankCount) {// 現在調査対象の順位とマッチする場合
					ranked.add(ply.get(i)); // コレクションの最後尾に追加
					rankCount++; // 次の順位を判定
				}
			}
		}
		return ranked; // ソート済のプレイヤー情報

	}

	public void load() { // 「now loading...」風
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
		}
	}

	public void load(int tick) { // 長いロード 仮引数の値で長さを調節可能
		try {
			Thread.sleep(500 * Math.abs(tick)); // 負数の誤入力対策
		} catch (InterruptedException e) {
		}
	}

}
