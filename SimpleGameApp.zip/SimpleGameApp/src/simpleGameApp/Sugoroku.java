package simpleGameApp;

import java.util.ArrayList;
import java.util.List;

/*
 * 
 * simpleGameApp
 * 簡易CUIすごろくゲーム
 * 
 * いるもの
 * MAP 文字列型 スタート地点は'S'、ゴールは'G'
 * dice 整数型乱数 1～6
 * 駒 プレイヤー数ぶん List<Player>
 * 
 * 位置情報 プレイヤーごと DTO（何マス目か、何マスに止まっているか）
 * (休み回数 プレイヤーごと）
 * （各マスのイベント情報    配列型、もしくはList）
 * ターン 整数型
 * 
 * 仕様
 * ・マス
 * S スタート
 * G ゴール
 * * 白マス 何も起こらない
 * + いいことが起こる
 * 進む、もう一回行動
 * - 悪いことが起こる
 * 戻る、休み
 * 
 * ・ゴール
 * ビタ止まりじゃなくてもいい（越えたらOK）
 * 
 * （実装予定案件）
 * ターン終了時、確率でランダムイベントが発生（固定orターン経過で確率が上がる？）
 * アイテム/持ち点（通貨）のような要素を実装
 * 
 * クラス
 * SugorokuMap マップ情報、スタート、ゴール位置、ターン
 * Player DTO プレイヤー情報
 * →プレイヤー名、現在地、順位
 * Location DTO 現在地情報（Playerクラスに格納）
 * SugorokuFunction すごろくの進行機能
 * →ダイスを振る、マップ確認、ターン管理等
 * Sugoroku エントリポイント
 * 
 */

public class Sugoroku {

	public static void main(String[] args) {
		SugorokuFunction func = new SugorokuFunction();// さいころを振る動作やら、マップ確認やら
		final int MAP_SIZE = 5;					//マップの大きさ
//		final int MAP_SIZE = func.chooseMapSize();
		SugorokuMap map = new SugorokuMap(MAP_SIZE);// マップを生成

		final int PLAYER = 4;					//プレイヤーの数
//		final int PLAYER = func.playersSelect(); （入力予定）
		int currentTurn=0;						//現在の手番を判定する変数
		int goaledPlayer=0;					//ゴールしたプレイヤーの数
		List<Player> ply = new ArrayList<>();	// 各プレイヤーの位置情報、順位
//		String[] name = func.inputName();
		String[] name = { "A", "B", "C", "D" };	//プレイヤー名
//		func.createPlayer(PLAYER,name);
		for (int i = 0; i < PLAYER; i++) {		// 各プレイヤーをスタート位置に配置
			ply.add(new Player(new Location(), name[i]));
		}
		while (goaledPlayer<PLAYER) {			//全員がゴールするまで
			
			Player turnPlayer = ply.get((currentTurn) % PLAYER);	//現在のプレイヤー
			if (turnPlayer.getRank() == 0) {	//順位が付いていない＝ゴールしていない
				func.turnStart(turnPlayer);		//ターン開始
				switch (func.input()) {			//コマンド入力で条件分岐
				case "1":						//「1」でサイコロを振る
					int dice = func.diceRoll();

					if (turnPlayer.getLocation() + dice >= MAP_SIZE) {	//ゴールマスを越えたら
						func.load(2);
						System.out.println("goal!");
						func.goalRank(turnPlayer);		// 順位の設定
						goaledPlayer++;					//ゴール人数のカウント
						break;	//switch文を抜け出す
					} else {
						
						func.load(2);
						// プレイヤーが進む
						turnPlayer.setLocation(map, turnPlayer.getLocation(), dice);
						func.load();
						func.checkMap(map,turnPlayer,false);	//現在地情報の表示
						break;	//switch文を抜け出す
					}
				case "2":	//2でマップ情報の取得
					func.checkMap(map,turnPlayer,true);	//現在地情報の表示
					continue;		// while文の先頭に戻る ターンの計算は行わない
				default:	//それ以外
					System.out.println("【ERROR】不正な入力です。もう一度入力してください。");
					continue;
				}
				// （予定）
				// 現在地のチェック
				// 現在地のマスに応じた処理をさせる

				func.turnChange();// 最後にターンを切り替え
			}

			currentTurn++;		//ターン情報を更新

		}

		func.showResult(ply);//ゲーム結果の表示

	}

}
