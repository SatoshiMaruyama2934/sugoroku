package simpleGameApp;

/*
 * プレイヤー情報
 * ・プレイヤー名
 * ・現在位置
 * ・順位
 * 
 */

public class Player {
	public Location location;
	public final String PLAYER_NAME;
	public int rank=0;
	
	public int getRank() {
		return rank;
	}
	
	public void setRank(int rank) {
		this.rank=rank;
	}
	public void setLocation(SugorokuMap map,int loc,int dice) {
		location.setCurrent(location.getCurrent()+dice);
		location.setSquare(map.getMap().charAt(location.getCurrent()));
	}
	
	public int getLocation() {
		return location.getCurrent();
	}
	public String getName() {
		return PLAYER_NAME;
	}
	public char getSquare() {
		return location.getSquare();
	}
	
	public Player(Location loc,String name){
		location=loc;
		PLAYER_NAME=name;
	}

	
}
