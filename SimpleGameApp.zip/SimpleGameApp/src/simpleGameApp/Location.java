package simpleGameApp;
/*
 * 現在地情報
 * ・現在地（nマス目）
 * ・マスの情報
 */

public class Location {
	private int current=0;
	private char square;
	
	public int getCurrent() {
		return current;
	}
	public void setCurrent(int current) {
		this.current=current;
	}
	public char getSquare() {
		return square;
	}
	public void setSquare(char square) {
		this.square=square;
	}
	public void setLocation(SugorokuMap map,int current,char square) {
		this.current=current;
		this.square=map.getMap().charAt(current);
		
	}
	
}
